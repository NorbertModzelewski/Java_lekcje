public class Main {
    public static void main(String[] args) {
        Auto fiat = new Auto(2020, "Fiat",  "Multipla");
        fiat.wyswietl();
        Helikopter Guimbal =new Helikopter("Helikopters", "Robinson", 2020, 5, "helikopter" );

    }
}
