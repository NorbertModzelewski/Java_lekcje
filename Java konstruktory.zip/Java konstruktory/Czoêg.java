public class Czołg {
    public String marka;
    public String model;
    public int rocznik;
    public int kaliber;
    public String rok_produkcji;
}

